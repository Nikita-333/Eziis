import math
from rake_nltk import Rake
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.probability import FreqDist
import string
from nltk.tokenize import sent_tokenize
from summarizer.sbert import SBertSummarizer
def summarize_text_with_rake(text, num_keywords=15):

    rake = Rake()

    rake.extract_keywords_from_text(text)

    keywords = rake.get_ranked_phrases()[:num_keywords]

    return ','.join(keywords[:4])

# input_text = "Электрокардиограмма, также называемая ЭКГ или ЭКГ , часто делается в кабинете врача, в клинике или в больничной палате. Аппараты ЭКГ являются стандартным оборудованием в операционных и машинах скорой помощи. Некоторые персональные устройства, например умные часы, предлагают мониторинг ЭКГ . Спросите своего поставщика медицинских услуг, подходит ли вам этот вариант."
# keywords = summarize_text_with_rake(input_text)
# print(*keywords, sep=", ")

def summarize_text_advanced(text, num_sentences=2):
    sentences = sent_tokenize(text)

    stop_words = set(stopwords.words("english") + list(string.punctuation) + ['is', 'are', 'am', 'in', 'on', 'at', 'to', 'and', 'or', 'if', 'this', 'for', 'you'])

    term_freq_doc = FreqDist([word for word in word_tokenize(text.lower()) if word.isalnum() and word not in stop_words])

    max_freq_doc = term_freq_doc.most_common(1)[0][1]

    num_docs = len(sentences)

    sentence_weights = {}

    for sentence in sentences:

        sentence_weight = 0

        for word in word_tokenize(sentence.lower()):
            if word.isalnum() and word not in stop_words:
                term_freq_sentence = FreqDist([word for word in word_tokenize(sentence.lower()) if word.isalnum() and word not in stop_words])[word]
#Для каждого слова в предложении вычисляется вес, учитывающей частоту слова в предложении, частоту слова в документе, и логарифм отношения общего числа предложений к числу предложений, содержащих данное слово.
                weight = term_freq_sentence * 0.5 * (1 + term_freq_doc[word] / max_freq_doc) * math.log(num_docs / sum(1 for sent in sentences if word in word_tokenize(sent.lower()) and word.isalnum() and word not in stop_words))

                sentence_weight += weight

        sentence_weights[sentence] = sentence_weight

    top_sentences = sorted(sentence_weights, key=sentence_weights.get, reverse=True)[:num_sentences]

    return ' '.join(top_sentences[:4])

# input_text = "Электрокардиограмма записывает электрические сигналы в сердце. Это распространенный и безболезненный тест, используемый для быстрого выявления проблем с сердцем и мониторинга его здоровья. Электрокардиограмма, также называемая ЭКГ или ЭКГ , часто делается в кабинете врача, в клинике или в больничной палате. Аппараты ЭКГ являются стандартным оборудованием в операционных и машинах скорой помощи. Некоторые персональные устройства, например умные часы, предлагают мониторинг ЭКГ . Спросите своего поставщика медицинских услуг, подходит ли вам этот вариант."
# summary = summarize_text_advanced(input_text)
# print("Реферат:")
# print(summary)

# body = """An electrocardiogram records the electrical signals in the heart. It's a common and painless test used to quickly detect heart problems and monitor the heart's health. An electrocardiogram — also called ECG or EKG — is often done in a health care provider's office, a clinic or a hospital room. ECG machines are standard equipment in operating rooms and ambulances. Some personal devices, such as smartwatches, offer ECG monitoring. Ask your health care provider if this is an option for you."""
model = SBertSummarizer('paraphrase-MiniLM-L6-v2')

# result = model(body, num_sentences=3)
#print(result)