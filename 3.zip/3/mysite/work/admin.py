from django.contrib import admin
from work.models import FileProject

admin.site.register(FileProject)
