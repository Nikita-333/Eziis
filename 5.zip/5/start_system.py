from analyze.listener import Listener


Listener().start_listen()
