class MatchError(Exception):
    pass
